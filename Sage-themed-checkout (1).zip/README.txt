SAGE THEMED CHECKOUT
======================

This package contains a themed checkout page matching the Sage website shown in the
reference screenshot: dark olive/black background, cream typography, gold accents,
subtle grid, and the same editorial/serif visual language.

IMPORTANT:
- The left side is fully themed and can be used alongside your existing payment UI.
- The included payment area is a visual placeholder.
- To take real payments, keep your existing Stripe Payment Element / hosted Checkout
  integration and place it in the marked area.
- Do not put Stripe secret keys in this HTML file.
